 
1.use the inbuilt functions and find the minimum ,maximum and average amount from the order table.?

select
min (Amount) ,
max (Amount) ,
avg (Amount)
from order 


2.create a user-defined function which will multiply the given number with 10 ?

create function Multiple (@a int )
returns int 
as
begin
declare @ result int = 10*@a
end;

3.use the case statement to check if 100 is less than 200,greater than 200 or equel to 200 and print the corresponding value ?

select 
case 
when 100 < 200 then '100 is less than 200'
when 100 > 200 then '100 is greater than 200'
else '100 is equal to 200'
end

4.Using case statement ,find the status of amount.Set the status of amount as high amount,low amount or medium amount based upon the condition ?

select * amount 
case 
when amount > 1000000 then 'high amount'
when amount between 500000 and  1000000 then 'medium amount'
else  'low amount'
end
from order table 

5.create a user-defined function ,to fetch the amount greater than then given input ?

create function test (@Amount integer)
returns table 
as 
return 
select * from SomeTable where Amount>@Amount
go
 

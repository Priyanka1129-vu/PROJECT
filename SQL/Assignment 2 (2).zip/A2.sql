CREATE DATABASE ASSIGNMENT2

USE ASSIGNMENT2

Tasks To Be Performed:

1. Create a customer table which comprises of these columns: �customer_id�,
�first_name�, �last_name�, �email�, �address�, �city�,�state�,�zip� 



CREATE TABLE CUSTOMER (CUSTOMER_ID INT ,FIRST_NAME VARCHAR(20), LAST_NAME VARCHAR(20),
EMAIL VARCHAR(30),   ADDRESS VARCHAR(30),CITY VARCHAR(30), STATE VARCHAR(20),ZIP INT )


2. Insert 5 new records into the table


INSERT INTO CUSTOMER VALUES (10,'JEMMI','JORDAN','HEEMI@GMAIL.COM','2ND FLOOR VV PURAM','SANJOSE','KERALA',234),
							(20,'NEHA','JSIGH','NEHAI@GMAIL.COM','3ND FLOOR KR PURAM','SANJOSE','KERALA',23434),
							(30,'GAGANA','JORDAN','GAGAN@GMAIL.COM','4TH FLOOR VV PURAM','SANJOSE','GOA',22334),
							(40,'AKASH','THORAT','AKASH@GMAIL.COM','7ND FLOOR IT ROAD','BANGALORE','KARNATAKA',56134),
							(50,'CHANDAN','GOWDA','CHANDAN@GMAIL.COM','9TH FLOOR GANESH PURAM','RAMNAGAR','KARNATAKA',211134)



3. Select only the �first_name� and �last_name� columns fromthe customer
table

SELECT FIRST_NAME ,LAST_NAME FROM CUSTOMER



4. Select those records where �first_name� starts with �G� and city is �SanJose�. 


SELECT * FROM CUSTOMER WHERE FIRST_NAME LIKE 'G%' AND CITY='SANJOSE'


5. Select those records where Email has only �gmail�. 



SELECT * FROM CUSTOMER WHERE EMAIL LIKE '%GMAIL%'



6. Select those records where the �last_name� doesn't end with �A�.

SELECT * FROM CUSTOMER WHERE LAST_NAME NOT LIKE '%A'
 Create a view named �customer_san_jose� which comprises of onlythosecustomers who are from San Josemer_san_jose� which comprises of onlythose


 create a view 'customer_san_jose'
 as-
 select*from customer
 where customer =sanjose

2. Inside a transaction, update the first name of the customer to Franciswhere the last name is Jordan:
a. Rollback the transaction
b. Set the first name of customer to Alex, where the last nameisJordanbegin transactionupdate customer set firstname = 'Francis' where lastname  = 'jordan'a) begin transaction update customer set firstname = 'francis' where lastname = 'jordan'rollback transactionb)update customer set firstname = 'alex' where lastname = 'jordan'3. Inside a TRY... CATCH block, divide 100 with 0, print the default error
message

begin try
declare @ num1 int = 100,@num2 int = 0
select @ num1/@num2
end try
begin catch
select 'there is error with query ,please fix it before run'
end catch
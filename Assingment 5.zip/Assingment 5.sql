1. Arrange the �Orders� dataset in decreasing order of amount.

select *from orders  order by amount desc.

2. Create a table with the name �Employee_details1� consisting of these
columns: �Emp_id�, �Emp_name�, �Emp_salary�. Create another table with
the name �Employee_details2� consisting of the same columns as the first table

create table Employee_details1 (Emp_id int, Emp_name varchar (20) ,Emp_salary float)

insert into Employee_details1 
values (1,'kumar',200000)
insert into Employee_details1
values (2,'sumit',400000)
insert into Employee_details1
values (3,'kumit',500000)
insert into Employee_details1
values (4,'sneha',50000)
insert into Employee_details1
values (5,'neha',700000)

select * from Employee_details1 

create table Employee_details2 (Emp_id int, Emp_name varchar (20) ,Emp_salary float)
insert into Employee_details2
values (1,'kumar',200000)
insert into Employee_details2
values (2,'sumit',400000)
insert into Employee_details2
values (3,'archana',600000)
insert into Employee_details2
values (4,'hari',100000)
insert into Employee_details2
values (5,'krishna',300000)

select * from Employee_details2

3 Apply the UNION operator on these two tab

  select * from Employee_details1 
  union
  select * from Employee_details2

4  Apply the INTERSECT operator on these two tables

 select * from Employee_details1 
 intersect
 select * from Employee_details2

5.Apply the EXCEPT operator on these two tables
 
 select * from Employee_details1 
 except
 select * from Employee_details2
